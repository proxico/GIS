#! /bin/sh

java -Xmx512m -jar osm2po-core-4.8.8-signed.jar prefix=hh tileSize=x http://download.geofabrik.de/europe/germany/hamburg-latest.osm.pbf

